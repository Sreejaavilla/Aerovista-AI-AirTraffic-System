# AEROVISTA — Cognitive Air Traffic Harmony System (Hackathon Demo)

This repository contains a lightweight, GitHub-ready demo of **AEROVISTA**, an AI-assisted air traffic coordination prototype with:

- React frontend (holographic-like 3D airspace using Three.js)
- Flask backend with simple AI prediction endpoints and Flask-SocketIO for real-time events
- Simulated AI logic for staffing optimization & punctuality predictions
- Instructions to run locally for a hackathon demo
