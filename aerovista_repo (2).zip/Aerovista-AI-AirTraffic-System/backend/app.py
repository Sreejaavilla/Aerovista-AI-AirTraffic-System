from flask import Flask, jsonify
from flask_socketio import SocketIO, emit
from threading import Event
import random
import numpy as np

app = Flask(__name__)
app.config['SECRET_KEY'] = 'aerovista-demo-secret'
socketio = SocketIO(app, cors_allowed_origins='*', async_mode='eventlet')

stop_event = Event()

# Simple simulated AI: predicts congestion score (0-100) and suggests staffing adjustments
def generate_prediction():
    base = 40
    while not stop_event.is_set():
        weather_factor = random.choice([0, 5, -5, 10, -10])
        traffic_spike = np.random.poisson(1)
        congestion = max(0, min(100, base + weather_factor + traffic_spike*10 + random.randint(-8,8)))
        punctuality_risk = max(0, 100 - congestion - random.randint(-5,5))
        suggested_staff_delta = 0
        if congestion > 65:
            suggested_staff_delta = 2
        elif congestion > 45:
            suggested_staff_delta = 1
        elif congestion < 30:
            suggested_staff_delta = -1
        payload = {
            'congestion': int(congestion),
            'punctuality_risk': int(punctuality_risk),
            'suggested_staff_delta': suggested_staff_delta,
            'message': f'AI Suggestion: adjust staff by {suggested_staff_delta} (congestion {int(congestion)})'
        }
        socketio.emit('ai_prediction', payload, namespace='/ai')
        base += random.randint(-3,3)
        base = max(15, min(85, base))
        socketio.sleep(6)


@app.route('/health')
def health():
    return jsonify({'status':'ok'})


@app.route('/predict')
def predict():
    congestion = random.randint(20,80)
    return jsonify({
        'congestion': congestion,
        'punctuality_risk': max(0,100-congestion)
    })


@socketio.on('connect', namespace='/ai')
def connect():
    emit('connected', {'msg':'connected to AEROVISTA AI stream'})


thread = None

@socketio.on('start_stream', namespace='/ai')
def start_stream(data):
    global thread
    if thread is None:
        thread = socketio.start_background_task(generate_prediction)
        emit('stream_started', {'msg':'AI stream started'})


if __name__ == '__main__':
    try:
        socketio.run(app, host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        stop_event.set()
