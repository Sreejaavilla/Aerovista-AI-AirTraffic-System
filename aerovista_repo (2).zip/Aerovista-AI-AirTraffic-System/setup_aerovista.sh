#!/bin/bash
# One-click project generator (already generated here in this package)
echo "This package already contains the project under the current folder."
echo "To initialize git and push, run the following commands manually:"
echo "  git init"
echo "  git add ."
echo "  git commit -m 'Initial Aerovista demo'"
echo "  git branch -M main"
echo "  git remote add origin https://github.com/Sreejaavilla/Aerovista-AI-AirTraffic-System.git"
echo "  git push -u origin main"
