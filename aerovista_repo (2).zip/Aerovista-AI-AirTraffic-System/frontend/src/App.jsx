import React, { useEffect, useRef, useState } from 'react'
import io from 'socket.io-client'
import * as THREE from 'three'

const SOCKET_URL = 'http://localhost:5000/ai'

export default function App(){
  const mountRef = useRef(null)
  const [connected, setConnected] = useState(false)
  const [aiData, setAiData] = useState({congestion:0, punctuality_risk:0, suggested_staff_delta:0, message:''})
  const [staffLevel, setStaffLevel] = useState(8)

  useEffect(()=>{
    const socket = io(SOCKET_URL, {path: '/socket.io/', transports: ['websocket'], autoConnect: true, withCredentials: false})
    socket.on('connect', ()=>{ setConnected(true); socket.emit('start_stream') })
    socket.on('ai_prediction', (data)=>{ setAiData(data) })
    socket.on('disconnect', ()=> setConnected(false))
    return ()=>{ socket.disconnect() }
  },[])

  useEffect(()=>{
    const current = mountRef.current
    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(75, current.clientWidth/current.clientHeight, 0.1, 1000)
    camera.position.z = 30
    const renderer = new THREE.WebGLRenderer({antialias:true, alpha:true})
    renderer.setSize(current.clientWidth, current.clientHeight)
    current.appendChild(renderer.domElement)

    const globeGeo = new THREE.SphereGeometry(10, 32, 32)
    const globeMat = new THREE.MeshBasicMaterial({wireframe:true, opacity:0.2, transparent:true})
    const globe = new THREE.Mesh(globeGeo, globeMat)
    scene.add(globe)

    const planeMeshes = []
    for(let i=0;i<12;i++){
      const geo = new THREE.SphereGeometry(0.35,8,8)
      const mat = new THREE.MeshBasicMaterial()
      const mesh = new THREE.Mesh(geo, mat)
      mesh.position.set((Math.random()-0.5)*18, (Math.random()-0.5)*10, (Math.random()-0.5)*6)
      planeMeshes.push({mesh, vx:(Math.random()-0.5)*0.6, vy:(Math.random()-0.5)*0.2})
      scene.add(mesh)
    }

    function animate(){
      requestAnimationFrame(animate)
      globe.rotation.y += 0.002
      planeMeshes.forEach(p=>{
        p.mesh.position.x += p.vx * 0.6
        p.mesh.position.y += p.vy * 0.3
        if(Math.abs(p.mesh.position.x) > 22) p.vx *= -1
        if(Math.abs(p.mesh.position.y) > 12) p.vy *= -1
      })
      renderer.render(scene, camera)
    }
    animate()

    return ()=>{
      renderer.dispose()
      current.removeChild(renderer.domElement)
    }
  },[])

  useEffect(()=>{
    if(aiData.suggested_staff_delta){
      setStaffLevel(prev => Math.max(3, Math.min(20, prev + aiData.suggested_staff_delta)))
    }
  }, [aiData])

  return (
    <div className="app">
      <div className="left">
        <div ref={mountRef} className="three-canvas" />
      </div>
      <div className="right">
        <h2>AEROVISTA — Demo</h2>
        <p>Status: {connected? 'Connected to AI stream' : 'Disconnected'}</p>
        <div className="panel">
          <h3>AI Prediction</h3>
          <p>Congestion: {aiData.congestion}</p>
          <p>Punctuality Risk: {aiData.punctuality_risk}</p>
          <p>Suggestion: {aiData.message}</p>
        </div>
        <div className="panel">
          <h3>Staffing Meter</h3>
          <p>Active Controllers: {staffLevel}</p>
          <div className="meter"><div className="meter-fill" style={{width: `${(staffLevel/20)*100}%`}}/></div>
        </div>
        <div className="panel">
          <h3>Quick Controls</h3>
          <button onClick={()=>setStaffLevel(s=>Math.max(3,s-1))}>Decrease Staff</button>
          <button onClick={()=>setStaffLevel(s=>Math.min(20,s+1))}>Increase Staff</button>
        </div>
      </div>
    </div>
  )
}
